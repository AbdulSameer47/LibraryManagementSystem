package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;

public class verifymember {

	private JFrame frmVerifyMember;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					verifymember window = new verifymember();
					window.frmVerifyMember.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public verifymember() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmVerifyMember = new JFrame();
		frmVerifyMember.getContentPane().setBackground(Color.WHITE);
		frmVerifyMember.setTitle("VERIFY MEMBER");
		frmVerifyMember.setBounds(100, 100, 583, 428);
		frmVerifyMember.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmVerifyMember.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.YELLOW);
		panel.setBounds(39, 37, 352, 183);
		frmVerifyMember.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblStudentId = new JLabel("STUDENT ID");
		lblStudentId.setBounds(34, 63, 70, 14);
		panel.add(lblStudentId);
		
		textField = new JTextField();
		textField.setBounds(112, 60, 151, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton btnVerify = new JButton("VERIFY");
		btnVerify.setBounds(129, 120, 89, 23);
		panel.add(btnVerify);
		
		JLabel lblVerifyMember = new JLabel("VERIFY MEMBER");
		lblVerifyMember.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblVerifyMember.setHorizontalAlignment(SwingConstants.CENTER);
		lblVerifyMember.setBounds(91, 11, 151, 14);
		panel.add(lblVerifyMember);
	}
}
