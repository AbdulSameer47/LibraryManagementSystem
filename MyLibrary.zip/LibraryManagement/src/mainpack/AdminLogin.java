package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JFormattedTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.Toolkit;

public class AdminLogin {

	private JFrame frame;
	private JFormattedTextField txtUsername;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin window = new AdminLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(AdminLogin.class.getResource("/lib/admin.png")));
		frame.setBounds(100, 100, 700, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 684, 103);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(AdminLogin.class.getResource("/lib/admintitle.jpg")));
		lblNewLabel.setBounds(0, 0, 684, 103);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(128, 128, 128));
		panel_1.setBounds(0, 103, 684, 308);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		JLabel label = new JLabel("");
		label.setBounds(231, 98, 270, 14);
		panel_1.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(231, 172, 270, 14);
		panel_1.add(label_1);
		
		
		txtUsername = new JFormattedTextField();
		txtUsername.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				label.setText(null);
				
			}
		});
		txtUsername.setBounds(231, 63, 270, 32);
		panel_1.add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Arial", Font.PLAIN, 20));
		lblUsername.setBounds(119, 75, 102, 14);
		panel_1.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Arial", Font.PLAIN, 20));
		lblPassword.setBounds(119, 146, 102, 14);
		panel_1.add(lblPassword);
		
		
		JButton btnLogin = new JButton("Log-in");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
Class.forName("com.mysql.jdbc.Driver");
					
 java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
Statement st=con.createStatement();
		String s="select username,password from admin";
		ResultSet rs=st.executeQuery(s);
		String un,pw;
		boolean found=false;
		un=txtUsername.getText();
		pw=passwordField.getText();
		while(rs.next()) {
		 if(un.equals(rs.getString(1))  && pw.equals(rs.getString(2))) {
			 found=true;
			 break;
		 }
		 
		}
		if(found) {
			new admindashboard();
			
				}
		
		else
			JOptionPane.showMessageDialog(null, "Invalid Credentials");
		
				}
				catch(Exception e) { 
					JOptionPane.showMessageDialog(null, e);
					
				}
			}
		});
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(txtUsername.getText().trim().isEmpty() && passwordField.getText().trim().isEmpty()) {
					label.setText("username is empty");
					label_1.setText("Password is empty");
				}
				else if(txtUsername.getText().trim().isEmpty()) {
					label.setText("username is empty");
				}
				else if(passwordField.getText().trim().isEmpty()) {
					label_1.setText("Password is empty");
				}
			}
		});
		btnLogin.setBackground(new Color(100, 149, 237));
		btnLogin.setBounds(262, 219, 89, 23);
		panel_1.add(btnLogin);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtUsername.setText(null);
				passwordField.setText(null);
			}
		});
		btnReset.setBackground(new Color(135, 206, 250));
		btnReset.setBounds(388, 219, 89, 23);
		panel_1.add(btnReset);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(231, 140, 270, 32);
		panel_1.add(passwordField);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnExit.setBounds(909, 693, 90, 25);
		panel_1.add(btnExit);
		frame.setVisible(true);
	    
		
	}
}
