package mainpack;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;

import com.mysql.jdbc.Connection;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.Toolkit;

public class admindashboard {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admindashboard window = new admindashboard();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public admindashboard() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(admindashboard.class.getResource("/lib/admin.png")));
		frame.setBounds(100, 100, 912, 611);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 896, 572);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel label_1 = new JLabel("1");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label_1.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					JOptionPane.showMessageDialog(null,"Driver Loaded");
					Connection con= 
							(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","root");
								    Statement st=con.createStatement();		
							st.executeUpdate("create database if not exists library");
							JOptionPane.showMessageDialog(null,"Database Created");
							st.executeUpdate("use library");
											
					String s="create table if not exists admin(username varchar(10) primary key,password varchar(10))";
					st.executeUpdate(s);
					JOptionPane.showMessageDialog(null,"Admin Table Created");
					String add="insert inti admin values('sameer','12345678')";
					JOptionPane.showMessageDialog(null,"Admin Added");
					
			 String s1="create table if not exists librarian(username varchar(20) primary key,dob date ,gender varchar(6),password varchar(15));";
			  st.executeUpdate(s1);
				JOptionPane.showMessageDialog(null,"Librarian Table Created");	
				
				String s2="create table if not exists book(bookid varchar(10) primary key,booktitle varchar(30),bookauthor varchar(30),bookpublisher varchar(30),quantity int);";
				st.executeUpdate(s2);
				JOptionPane.showMessageDialog(null, "book Table created");
								
				
				String s3="create table if not exists user(username varchar(20) primary key,password varchar(15),dob date,email varchar(20),gender varchar(7),photo blob not null)";
						
				st.executeUpdate(s3);
				JOptionPane.showMessageDialog(null, "User Table created");	
				
				
				String s4=" create table if not exists transaction(username varchar(20),bookid varchar(20),issuedate date,returndate date,foreign key(username) references user(username) on delete cascade,foreign key(bookid) references book(bookid) on delete cascade)";
				st.executeUpdate(s4);
				JOptionPane.showMessageDialog(null, "transaction table created Table created");
				
				String s5=" create table if not exists returnbook(username varchar(20),bookid varchar(20),issuedate date,returndate date,fine varchar(10),foreign key(username) references user(username) on delete cascade,foreign key(bookid) references book(bookid) on delete cascade);";
				st.executeUpdate(s5);
				JOptionPane.showMessageDialog(null, "Book Return table created Table created");
							}
							catch(Exception e1) {
								JOptionPane.showMessageDialog(null, e1);	
							}	
							
						}
					});
					
					
					

		label_1.setIcon(new ImageIcon(admindashboard.class.getResource("/lib/database.png")));
		label_1.setBounds(44, 411, 150, 150);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("2");
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label_2.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					JOptionPane.showMessageDialog(null,"Driver Loaded");
					Connection con= 
							(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","root");
								    Statement st=con.createStatement();		
							st.executeUpdate("drop database if exists library");
							JOptionPane.showMessageDialog(null,"Database Library Removed\n all the data related has been deleted");
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);	
				}	
				
			}
			
		});
		label_2.setIcon(new ImageIcon(admindashboard.class.getResource("/lib/dropdata.png")));
		label_2.setBounds(223, 411, 150, 150);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("3");
		label_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				label_3.setCursor(new Cursor(Cursor.HAND_CURSOR));
				new addlibrarian();
			}
		});
		label_3.setIcon(new ImageIcon(admindashboard.class.getResource("/lib/addlibrarian.png")));
		label_3.setBounds(44, 224, 150, 150);
		panel.add(label_3);
		
		JLabel lblAdminDashboard = new JLabel("ADMIN DASHBOARD");
		lblAdminDashboard.setFont(new Font("Microsoft Himalaya", Font.BOLD, 60));
		lblAdminDashboard.setBounds(184, 11, 451, 72);
		panel.add(lblAdminDashboard);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(admindashboard.class.getResource("/lib/david-van-dijk-3LTht2nxd34-unsplash.jpg")));
		label.setBounds(0, 0, 896, 572);
		panel.add(label);
		frame.setVisible(true);
	}
}
