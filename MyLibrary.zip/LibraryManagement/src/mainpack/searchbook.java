package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class searchbook {

	private JFrame frmSearchBook;
	private JTable table;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					searchbook window = new searchbook();
					window.frmSearchBook.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public searchbook() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSearchBook = new JFrame();
		frmSearchBook.setTitle("SEARCH BOOK");
		frmSearchBook.setBounds(100, 100, 450, 300);
		frmSearchBook.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSearchBook.getContentPane().setLayout(null);
		
		table = new JTable();
		table.setBounds(21, 179, 391, 71);
		frmSearchBook.getContentPane().add(table);
		
		JLabel lblEnterBookName = new JLabel("ENTER BOOK NAME ");
		lblEnterBookName.setBounds(78, 68, 114, 22);
		frmSearchBook.getContentPane().add(lblEnterBookName);
		
		textField = new JTextField();
		textField.setBounds(202, 69, 123, 20);
		frmSearchBook.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.setBounds(165, 122, 89, 23);
		frmSearchBook.getContentPane().add(btnSearch);
		
		JLabel lblSearchBooks = new JLabel("SEARCH BOOKS");
		lblSearchBooks.setBounds(10, 11, 114, 22);
		frmSearchBook.getContentPane().add(lblSearchBooks);
	}
}
