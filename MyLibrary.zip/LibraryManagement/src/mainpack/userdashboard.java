package mainpack;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JPasswordField;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.toedter.calendar.JDateChooser;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class userdashboard {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JTextField textField_1;
	String gender;
	String photopath=null;
	String path;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userdashboard window = new userdashboard();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public userdashboard() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(userdashboard.class.getResource("/lib/reading.png")));
		frame.getContentPane().setBackground(Color.PINK);
		frame.setBounds(100, 100,  912, 611);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUserName = new JLabel("User name");
		lblUserName.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblUserName.setBounds(134, 168, 163, 31);
		frame.getContentPane().add(lblUserName);
		
		textField = new JTextField();
		textField.setBounds(286, 168, 181, 31);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblPassword.setBounds(134, 229, 135, 31);
		frame.getContentPane().add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(286, 229, 181, 31);
		frame.getContentPane().add(passwordField);
		
		JLabel lblDob = new JLabel("DOB");
		lblDob.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblDob.setBounds(134, 297, 99, 31);
		frame.getContentPane().add(lblDob);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(286, 297, 181, 31);
		frame.getContentPane().add(dateChooser);
		
		JLabel lblMail = new JLabel("E-mail");
		lblMail.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblMail.setBounds(134, 361, 99, 37);
		frame.getContentPane().add(lblMail);
		
		textField_1 = new JTextField();
		textField_1.setBounds(289, 361, 178, 34);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblGender.setBounds(134, 422, 99, 31);
		frame.getContentPane().add(lblGender);
		
		
	
		
		JButton btnReset = new JButton("Reset");
		btnReset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setText(null);
				passwordField.setText(null);
				textField_1.setText(null);
				dateChooser.setDate(null);
			}
		});
		JLabel label = new JLabel("");
		label.setBackground(Color.WHITE);
		label.setBounds(649, 160, 163, 150);
		frame.getContentPane().add(label);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	btnBrowse1ActionPerformed(evt);
            }

			private void btnBrowse1ActionPerformed(java.awt.event.ActionEvent evt) {
				// TODO Auto-generated method stub
				JFileChooser chooser=new JFileChooser();
		        chooser.setCurrentDirectory(new File(System.getProperty("user.home")));
		        FileNameExtensionFilter fnef=new FileNameExtensionFilter("*.images", "jpg","png","jpeg");
		        chooser.addChoosableFileFilter(fnef);
		        int ans=chooser.showSaveDialog(null);
		        if (ans==JFileChooser.APPROVE_OPTION) {
		           File selectedPhoto=chooser.getSelectedFile();
		           String path=selectedPhoto.getAbsolutePath();
		           label.setIcon(resizeImageI(path,null));
		          photopath=path;
		        }else{JOptionPane.showMessageDialog(null,"  Photo Compulsory");
		           ;
		        }
			}
		
			private ImageIcon resizeImageI(String photopath,byte[] photo) {
				// TODO Auto-generated method stub
				 ImageIcon myPhoto=null;
			        if (photopath!=null) {
			            myPhoto=new ImageIcon(photopath);
			        }else{
			            myPhoto=new ImageIcon(photo);
			        }
			            Image img=myPhoto.getImage();
			            Image img1=img.getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
			            ImageIcon ph=new ImageIcon(img1); 
			            return ph;
				
			}
        });
		btnReset.setBounds(286, 504, 89, 23);
		frame.getContentPane().add(btnReset);
		
		JButton btnSubmit = new JButton("submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				String un,pw,email;
				double sal;
				String dt=null;
				un=textField.getText();
				pw=passwordField.getText();
				dt=dateChooser.getDateFormatString();
			//	gender=JCheckBox.getText();
				email=textField_1.getText();
				
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
				dt=sdf.format(dateChooser.getDate()); 
				 String filename = path;
				 InputStream is=new FileInputStream(new File(photopath));
				
				Class.forName("com.mysql.jdbc.Driver");
				   
				   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
				    String s="insert into user values(?,?,?,?,?,?)";
				    PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
				    ps.setString(1, un);
				    ps.setString(3, dt);
				    ps.setString(5, gender);
				    ps.setString(2, pw);
				   ps.setString(4, email);
				   ps.setBlob(6,is);
				
				    int r=ps.executeUpdate();
				    if(r==1)
				    	JOptionPane.showMessageDialog(null, r+" Record Inserted");
				  
				    
			}catch(Exception n) {
				JOptionPane.showMessageDialog(null, n);	
			}
		}
	});
	
		
		btnSubmit.setBounds(391, 504, 89, 23);
		frame.getContentPane().add(btnSubmit);
		
		JLabel lblUserRegistration = new JLabel("USER REGISTRATION");
		lblUserRegistration.setFont(new Font("Microsoft Himalaya", Font.BOLD, 50));
		lblUserRegistration.setBounds(225, 11, 416, 57);
		frame.getContentPane().add(lblUserRegistration);
		
		JCheckBox chckbxMale = new JCheckBox("male");
		chckbxMale.setBounds(278, 422, 68, 23);
		frame.getContentPane().add(chckbxMale);
		
		JCheckBox chckbxFemale = new JCheckBox("Female");
		chckbxFemale.setBounds(362, 422, 68, 23);
		frame.getContentPane().add(chckbxFemale);
		
		JLabel lblPhoto = new JLabel("Photo");
		lblPhoto.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPhoto.setBounds(695, 120, 80, 23);
		frame.getContentPane().add(lblPhoto);
		
		
		
		
		btnAdd.setBounds(686, 334, 89, 23);
		frame.getContentPane().add(btnAdd);
		
		frame.setVisible(true);
	}
}
