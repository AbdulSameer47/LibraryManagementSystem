package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class returnbook {

	private JFrame frmReturnBook;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					returnbook window = new returnbook();
					window.frmReturnBook.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public returnbook() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmReturnBook = new JFrame();
		frmReturnBook.setTitle("RETURN BOOK");
		frmReturnBook.setBounds(100, 100, 450, 300);
		frmReturnBook.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmReturnBook.getContentPane().setLayout(null);
		
		JLabel lblBookId = new JLabel("BOOK ID");
		lblBookId.setBounds(93, 73, 68, 14);
		frmReturnBook.getContentPane().add(lblBookId);
		
		textField = new JTextField();
		textField.setBounds(204, 70, 86, 20);
		frmReturnBook.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNoOfBooks = new JLabel("NO OF BOOKS");
		lblNoOfBooks.setBounds(93, 112, 86, 14);
		frmReturnBook.getContentPane().add(lblNoOfBooks);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(204, 109, 86, 20);
		frmReturnBook.getContentPane().add(textField_1);
		
		JButton btnReturn = new JButton("RETURN");
		btnReturn.setBounds(201, 163, 89, 23);
		frmReturnBook.getContentPane().add(btnReturn);
	}
}
