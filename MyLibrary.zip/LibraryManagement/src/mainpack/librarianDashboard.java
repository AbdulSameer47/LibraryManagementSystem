package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Panel;
import java.awt.SystemColor;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Button;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JRadioButton;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;

import java.awt.Canvas;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.awt.Toolkit;

public class librarianDashboard {

	private JFrame dashframe;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTable table;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTable table_1;
	private JTextField textField_17;
	private JTable table_3;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DASHBOARD window = new DASHBOARD();
					window.dashframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public librarianDashboard() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		dashframe = new JFrame();
		dashframe.setIconImage(Toolkit.getDefaultToolkit().getImage(librarianDashboard.class.getResource("/lib/librnlogo.png")));
		dashframe.getContentPane().setBackground(Color.WHITE);
		dashframe.setBounds(100, 100, 1300, 719);
		dashframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dashframe.getContentPane().setLayout(null);
		
		JPanel p1 = new JPanel();
		p1.setBounds(253, 0, 1030, 679);
		p1.setBackground(Color.WHITE);
		dashframe.getContentPane().add(p1);
		p1.setLayout(new CardLayout(0, 0));
		
		JPanel q4 = new JPanel();
		q4.setBackground(Color.PINK);
		p1.add(q4, "t4");
		q4.setLayout(null);
		
		textField_14 = new JTextField();
		textField_14.setBounds(272, 114, 297, 28);
		q4.add(textField_14);
		textField_14.setColumns(10);
		
		JLabel lblEnterBookName = new JLabel("Enter Book Name or ID");
		lblEnterBookName.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblEnterBookName.setBounds(10, 109, 252, 38);
		q4.add(lblEnterBookName);
		
		JButton button = new JButton("SEARCH BOOK");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("Driver loaded");
				Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
				System.out.println("Database Connected");
				
			String bookname=textField_14.getText();
				String s="Select * from book where booktitle='" + bookname + "'";
				 PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
				 
				Statement st=(Statement) con.createStatement();
				ResultSet rs=st.executeQuery(s);
				
				    
				table_1.setModel(DbUtils.resultSetToTableModel(rs));
				
				
			
				}
			catch(Exception ex) 
			{
				JOptionPane.showMessageDialog(null, ex);
			}			
		
	}
});

		
		button.setBackground(new Color(175, 238, 238));
		button.setBounds(351, 176, 139, 23);
		q4.add(button);
		
		table_1 = new JTable();
		table_1.setBounds(101, 332, 888, 311);
		q4.add(table_1);
		
		JLabel lblSearchBooks = new JLabel("Search Books");
		lblSearchBooks.setFont(new Font("Microsoft Himalaya", Font.BOLD, 50));
		lblSearchBooks.setBounds(10, 11, 312, 62);
		q4.add(lblSearchBooks);
		
		JLabel lblAvailableBooks = new JLabel("Available Books");
		lblAvailableBooks.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblAvailableBooks.setBounds(105, 283, 217, 38);
		q4.add(lblAvailableBooks);
		
		JPanel q6 = new JPanel();
		q6.setBackground(Color.PINK);
		p1.add(q6, "t6");
		q6.setLayout(null);
		
		JLabel lblStudentName = new JLabel("Student User Name");
		lblStudentName.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblStudentName.setBounds(97, 119, 209, 32);
		q6.add(lblStudentName);
		
		textField_17 = new JTextField();
		textField_17.setColumns(10);
		textField_17.setBounds(316, 120, 209, 31);
		q6.add(textField_17);
		
		JButton button_1 = new JButton("VERIFY MEMBER");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("Driver loaded");
					Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
					System.out.println("Database Connected");
					
				String username=textField_17.getText();
					String s="Select username,dob,email,gender from user where username='" + username + "'";
					 PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
					
					
					
					
					
					 
					Statement st=(Statement) con.createStatement();
					ResultSet rs=st.executeQuery(s);
					
					    
					table_3.setModel(DbUtils.resultSetToTableModel(rs));
				    //JOptionPane.showMessageDialog(null,"Verifed");
					
					
				
					}
				catch(Exception ex) 
				{
					JOptionPane.showMessageDialog(null, ex);
				}			
			
		}
	});
			
			
		button_1.setBackground(new Color(175, 238, 238));
		button_1.setBounds(368, 191, 139, 23);
		q6.add(button_1);
		
		JButton btnAddMember = new JButton("ADD MEMBER");
		btnAddMember.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new userdashboard();
			}
		});
		btnAddMember.setBackground(new Color(175, 238, 238));
		btnAddMember.setBounds(593, 129, 147, 23);
		q6.add(btnAddMember);
		
		table_3 = new JTable();
		table_3.setBounds(119, 341, 854, 292);
		q6.add(table_3);
		
		JLabel lblVerifyUser = new JLabel("VERIFY USER");
		lblVerifyUser.setFont(new Font("Microsoft Himalaya", Font.BOLD, 50));
		lblVerifyUser.setBounds(10, 11, 266, 57);
		q6.add(lblVerifyUser);
		
		JPanel q1 = new JPanel();
		q1.setBackground(Color.PINK);
		p1.add(q1, "t1");
		q1.setLayout(null);
		
		JLabel lblBookId = new JLabel("BOOK ID");
		lblBookId.setBounds(182, 129, 154, 27);
		lblBookId.setFont(new Font("Tahoma", Font.PLAIN, 23));
		q1.add(lblBookId);
		
		JLabel lblBookTitle = new JLabel("BOOK TITLE");
		lblBookTitle.setBounds(182, 189, 165, 27);
		lblBookTitle.setFont(new Font("Tahoma", Font.PLAIN, 22));
		q1.add(lblBookTitle);
		
		JLabel lblBookAuthor = new JLabel("BOOK AUTHOR");
		lblBookAuthor.setBounds(182, 247, 207, 27);
		lblBookAuthor.setFont(new Font("Tahoma", Font.PLAIN, 22));
		q1.add(lblBookAuthor);
		
		JLabel lblBookPublisher = new JLabel("BOOK PUBLISHER");
		lblBookPublisher.setBounds(182, 308, 198, 27);
		lblBookPublisher.setFont(new Font("Tahoma", Font.PLAIN, 22));
		q1.add(lblBookPublisher);
		
		JLabel lblAvailableStock = new JLabel("QUANTITY");
		lblAvailableStock.setBounds(182, 373, 198, 23);
		lblAvailableStock.setFont(new Font("Tahoma", Font.PLAIN, 22));
		q1.add(lblAvailableStock);
		
		textField = new JTextField();
		textField.setBounds(399, 134, 198, 27);
		q1.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(399, 189, 198, 27);
		textField_1.setColumns(10);
		q1.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(399, 252, 198, 27);
		textField_2.setColumns(10);
		q1.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(399, 313, 198, 27);
		textField_3.setColumns(10);
		q1.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setBounds(399, 369, 198, 27);
		textField_4.setColumns(10);
		q1.add(textField_4);
		
		JLabel lblAddBookTo = new JLabel("ADD BOOK TO LIBRARY");
		lblAddBookTo.setBounds(10, 11, 446, 67);
		lblAddBookTo.setFont(new Font("Microsoft Himalaya", Font.BOLD, 50));
		q1.add(lblAddBookTo);
		
		JButton btnSubmit_1 = new JButton("Add Book");
		btnSubmit_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				try {
					String bid,bn,ba,bp;
					int qty;
					String dt=null;
					bid=textField.getText();
					bn=textField_1.getText();
					ba=textField_2.getText();
					bp=textField_3.getText();
					 qty = Integer.parseInt(textField_4.getText());
					 
					
					
					
					

					
					Class.forName("com.mysql.jdbc.Driver");
					   
					   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
					    String s="insert into book values(?,?,?,?,?)";
					    PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
					    ps.setString(1, bid);
					    ps.setString(2, bn);
					    ps.setString(3, ba);
					    ps.setString(4, bp);
					    ps.setInt(5, qty);
					   
					
					
					    int r=ps.executeUpdate();
					    if(r==1)
					    	JOptionPane.showMessageDialog(null, r+" Book added");
					  
					}catch(Exception n) {
						JOptionPane.showMessageDialog(null, n);	
					}
				}
			});
			
		
		btnSubmit_1.setBounds(399, 436, 89, 23);
		btnSubmit_1.setBackground(new Color(175, 238, 238));
		q1.add(btnSubmit_1);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
				
			}
		});
		btnReset.setBounds(515, 436, 89, 23);
		btnReset.setBackground(new Color(175, 238, 238));
		q1.add(btnReset);
		
		JPanel q2 = new JPanel();
		q2.setBackground(Color.PINK);
		p1.add(q2, "t2");
		q2.setLayout(null);
		
		JLabel lblIssueBook = new JLabel("Issue Book");
		lblIssueBook.setFont(new Font("Microsoft Himalaya", Font.BOLD, 50));
		lblIssueBook.setBounds(10, 11, 282, 53);
		q2.add(lblIssueBook);
		
		JLabel lblBookId_1 = new JLabel("Book Id");
		lblBookId_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblBookId_1.setBounds(203, 210, 106, 27);
		q2.add(lblBookId_1);
		
		JLabel lblStudentId = new JLabel("Student User name");
		lblStudentId.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblStudentId.setBounds(131, 152, 196, 27);
		q2.add(lblStudentId);
		
		JLabel lblIssueDate = new JLabel("Issue Date\r\n");
		lblIssueDate.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblIssueDate.setBounds(203, 273, 139, 27);
		q2.add(lblIssueDate);
		
		JLabel lblDueDate = new JLabel("Due Date");
		lblDueDate.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblDueDate.setBounds(203, 334, 139, 27);
		q2.add(lblDueDate);
		
		textField_5 = new JTextField();
		textField_5.setBounds(341, 209, 181, 28);
		q2.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(341, 151, 181, 28);
		q2.add(textField_6);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(341, 273, 181, 27);
		q2.add(dateChooser);
		
		JDateChooser dateChooser_1 = new JDateChooser();
		dateChooser_1.setBounds(341, 334, 181, 27);
		q2.add(dateChooser_1);
		
		
		JButton btnSubmit = new JButton("Submit ");
		btnSubmit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
					String uid,bid;
					
					String rdate=null,idate=null;
					uid=textField_6.getText();
					bid=textField_5.getText();
					idate=dateChooser.getDateFormatString();
					rdate=dateChooser.getDateFormatString();
					
					
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
					idate=sdf.format(dateChooser.getDate()); 
					
					SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");
					rdate=sdf1.format(dateChooser.getDate()); 

					
					Class.forName("com.mysql.jdbc.Driver");
					   
					   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
					    String s="insert into transaction values(?,?,?,?)";
					    PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
					    ps.setString(1,uid);
					    ps.setString(2, bid);
					    ps.setString(3, idate);
					    ps.setString(4, rdate);
					   
					   
					
					
					    int r=ps.executeUpdate();
					    if(r==1)
					    	JOptionPane.showMessageDialog(null, r+" Record Inserted");
					  
					    
				}catch(Exception n) {
					JOptionPane.showMessageDialog(null, n);	
				}
			}
		});
		
		
		btnSubmit.setBackground(new Color(175, 238, 238));
		btnSubmit.setBounds(345, 417, 89, 23);
		q2.add(btnSubmit);
		
		JButton btnReset_1 = new JButton("Reset");
		btnReset_1.setBackground(new Color(175, 238, 238));
		btnReset_1.setBounds(444, 417, 89, 23);
		q2.add(btnReset_1);
		
		
		JPanel q3 = new JPanel();
		q3.setBackground(Color.PINK);
		p1.add(q3, "t3");
		q3.setLayout(null);
		
		JLabel lblBookId_2 = new JLabel("Book Id");
		lblBookId_2.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblBookId_2.setBounds(182, 145, 102, 27);
		q3.add(lblBookId_2);
		
		JLabel lblStudentId_1 = new JLabel("Student Username");
		lblStudentId_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblStudentId_1.setBounds(99, 86, 197, 27);
		q3.add(lblStudentId_1);
		
		JLabel lblDueDate_1 = new JLabel("Return Date");
		lblDueDate_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblDueDate_1.setBounds(164, 211, 132, 27);
		q3.add(lblDueDate_1);
		
		JLabel lblFineIfAny = new JLabel("Fine if any");
		lblFineIfAny.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblFineIfAny.setBounds(182, 271, 102, 27);
		q3.add(lblFineIfAny);
		
		table = new JTable();
		table.setFillsViewportHeight(true);
		
		table.setCellSelectionEnabled(true);
		table.setBounds(112, 413, 853, 255);
		q3.add(table);
		
		textField_9 = new JTextField();
		textField_9.setBounds(310, 90, 163, 28);
		q3.add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(310, 150, 163, 27);
		q3.add(textField_10);
		
		textField_13 = new JTextField();
		textField_13.setColumns(10);
		textField_13.setBounds(313, 271, 163, 28);
		q3.add(textField_13);
		JDateChooser dateChooser_2 = new JDateChooser();
		dateChooser_2.setBounds(310, 211, 163, 27);
		q3.add(dateChooser_2);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				

				try {
					String uid,bid,fine;
					
					String rdate=null,idate=null;
					uid=textField_9.getText();
					bid=textField_10.getText();
					
					rdate=dateChooser_2.getDateFormatString();
					fine=textField_13.getText();
					
					
					
					SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");
					rdate=sdf1.format(dateChooser.getDate()); 

					
					Class.forName("com.mysql.jdbc.Driver");
					   
					   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
					    String s="insert into returnbook values(?,?,?,?)";
					    PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
					    ps.setString(1,uid);
					    ps.setString(2, bid);
					    ps.setString(3, rdate);
					    ps.setString(4, fine);
					   
					   
					
					
					    int r=ps.executeUpdate();
					    if(r==1)
					    	JOptionPane.showMessageDialog(null, r+" Record Inserted");
					  
					    
				}catch(Exception n) {
					JOptionPane.showMessageDialog(null, n);	
				}
			}
		});
		
			
		btnSave.setBackground(new Color(175, 238, 238));
		btnSave.setBounds(313, 379, 86, 23);
		q3.add(btnSave);
		
		JButton btnReset_2 = new JButton("Reset");
		btnReset_2.setBackground(new Color(175, 238, 238));
		btnReset_2.setBounds(409, 379, 86, 23);
		q3.add(btnReset_2);
		
		JLabel lblReturnBook = new JLabel("RETURN BOOK");
		lblReturnBook.setFont(new Font("Microsoft Himalaya", Font.BOLD, 50));
		lblReturnBook.setBounds(10, 21, 313, 42);
		q3.add(lblReturnBook);
		
		
		
		JButton btnNewButton_1 = new JButton("ADD BOOK");
		btnNewButton_1.setBounds(47, 403, 140, 31);
		btnNewButton_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout c=(CardLayout)(p1.getLayout());
				c.show(p1, "t1");
			}
		});
		dashframe.getContentPane().add(btnNewButton_1);
		
		JButton btnReturnBook = new JButton("RETURN BOOK");
		btnReturnBook.setBounds(47, 544, 140, 31);
		btnReturnBook.setBackground(new Color(175, 238, 238));
		btnReturnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout c=(CardLayout)(p1.getLayout());
				c.show(p1, "t3");
			}
		});
		dashframe.getContentPane().add(btnReturnBook);
		
		JButton btnSearchBook = new JButton("SEARCH BOOK");
		btnSearchBook.setBounds(47, 274, 140, 31);
		btnSearchBook.setBackground(new Color(175, 238, 238));
		btnSearchBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout c=(CardLayout)(p1.getLayout());
				c.show(p1, "t4");
			}
		});
		dashframe.getContentPane().add(btnSearchBook);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\GV62 7RD\\Desktop\\LIBRARY\\LibraryManagement\\src\\lib\\librnlogo.png"));
		lblNewLabel.setBounds(-1, 0, 231, 234);
		dashframe.getContentPane().add(lblNewLabel);
		
		JButton btnIssueBook = new JButton("ISSUE BOOK");
		btnIssueBook.setBounds(47, 468, 140, 31);
		dashframe.getContentPane().add(btnIssueBook);
		btnIssueBook.setBackground(new Color(175, 238, 238));
		
		JButton btnVerifyMember = new JButton("VERIFY MEMBER");
		btnVerifyMember.setBounds(47, 343, 140, 31);
		dashframe.getContentPane().add(btnVerifyMember);
		btnVerifyMember.setBackground(new Color(175, 238, 238));
		btnVerifyMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout c=(CardLayout)(p1.getLayout());
				c.show(p1, "t6");
			}
		});
		btnIssueBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout c=(CardLayout)(p1.getLayout());
				c.show(p1, "t2");
			}
		});
		dashframe.setVisible(true);
		
		
		
		
		
	}
}
