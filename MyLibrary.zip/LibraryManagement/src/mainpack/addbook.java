//ADDBOOK
package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class addbook {

	private JFrame frmAddBook;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addbook window = new addbook();
					window.frmAddBook.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public addbook() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAddBook = new JFrame();
		frmAddBook.setTitle("ADD BOOK");
		frmAddBook.setBounds(100, 100, 450, 300);
		frmAddBook.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAddBook.getContentPane().setLayout(null);
		
		JLabel lblBookId = new JLabel("BOOK ID");
		lblBookId.setBounds(40, 43, 56, 14);
		frmAddBook.getContentPane().add(lblBookId);
		
		JLabel lblName = new JLabel("NAME\r\n");
		lblName.setBounds(40, 75, 46, 14);
		frmAddBook.getContentPane().add(lblName);
		
		JLabel lblAuthor = new JLabel("AUTHOR");
		lblAuthor.setBounds(40, 105, 46, 14);
		frmAddBook.getContentPane().add(lblAuthor);
		
		JLabel lblRackNo = new JLabel("RACK NO");
		lblRackNo.setBounds(40, 135, 46, 14);
		frmAddBook.getContentPane().add(lblRackNo);
		
		JLabel lblPrice = new JLabel("PRICE");
		lblPrice.setBounds(40, 164, 46, 14);
		frmAddBook.getContentPane().add(lblPrice);
		
		JLabel lblStatus = new JLabel("STATUS");
		lblStatus.setBounds(40, 194, 46, 14);
		frmAddBook.getContentPane().add(lblStatus);
		
		JLabel lblNoOfBooks = new JLabel("NO OF BOOKS");
		lblNoOfBooks.setBounds(40, 222, 102, 14);
		frmAddBook.getContentPane().add(lblNoOfBooks);
		
		textField = new JTextField();
		textField.setBounds(152, 40, 86, 20);
		frmAddBook.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(152, 72, 86, 20);
		frmAddBook.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(152, 102, 86, 20);
		frmAddBook.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(152, 132, 86, 20);
		frmAddBook.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(152, 161, 86, 20);
		frmAddBook.getContentPane().add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(152, 191, 86, 20);
		frmAddBook.getContentPane().add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(152, 219, 86, 20);
		frmAddBook.getContentPane().add(textField_6);
		
		JButton btnAddBook = new JButton("ADD BOOK");
		btnAddBook.setBounds(285, 71, 109, 23);
		frmAddBook.getContentPane().add(btnAddBook);
		
		JButton btnReset = new JButton("RESET");
		btnReset.setBounds(285, 155, 109, 23);
		frmAddBook.getContentPane().add(btnReset);
	}
}
