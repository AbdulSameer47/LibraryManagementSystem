package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.Toolkit;

public class userboard {

	private JFrame frame;
	private JTextField textField;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userboard window = new userboard();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public userboard() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(userboard.class.getResource("/lib/reading.png")));
		frame.setBounds(100, 100, 1006, 590);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.PINK);
		panel.setBounds(0, 0, 990, 551);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblWellcomeUser = new JLabel("WELLCOME USER");
		lblWellcomeUser.setFont(new Font("Microsoft Himalaya", Font.BOLD, 70));
		lblWellcomeUser.setBounds(268, 11, 447, 79);
		panel.add(lblWellcomeUser);
		
		JLabel lblSearchForBooks = new JLabel("Search For Books");
		lblSearchForBooks.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblSearchForBooks.setBounds(370, 101, 238, 37);
		panel.add(lblSearchForBooks);
		
		textField = new JTextField();
		textField.setBounds(358, 236, 276, 37);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblEnterBookName = new JLabel("Enter Book Name");
		lblEnterBookName.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblEnterBookName.setBounds(417, 194, 145, 31);
		panel.add(lblEnterBookName);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("Driver loaded");
					Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
					System.out.println("Database Connected");
					
					String bookname=textField.getText();
					String s="Select * from book where booktitle='" + bookname + "'";
					 PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
					
					
					
					
					
					 
					Statement st=(Statement) con.createStatement();
					ResultSet rs=st.executeQuery(s);
					
					    
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				
					}
				catch(Exception ex) 
				{
					JOptionPane.showMessageDialog(null, ex);
				}			
			
		}
	});

		
		btnSearch.setBounds(457, 284, 89, 23);
		panel.add(btnSearch);
		
		table = new JTable();
		table.setBounds(235, 534, 624, -160);
		panel.add(table);
		
		table_1 = new JTable();
		table_1.setBounds(162, 340, 709, 200);
		panel.add(table_1);
		
		JButton btnViewAllBooks = new JButton("View All Books");
		btnViewAllBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("Driver loaded");
					Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
					System.out.println("Database Connected");
					
					
					String s="Select * from book";
					 PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
					
					
					
					
					
					 
					Statement st=(Statement) con.createStatement();
					ResultSet rs=st.executeQuery(s);
					
					    
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				
					}
				catch(Exception ex) 
				{
					JOptionPane.showMessageDialog(null, ex);
				}			
			
		}
	});

				
		
		btnViewAllBooks.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewAllBooks.setBounds(751, 310, 120, 23);
		panel.add(btnViewAllBooks);
		frame.setVisible(true);
	}
}
