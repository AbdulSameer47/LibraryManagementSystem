package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.Font;

public class updatestatus {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updatestatus window = new updatestatus();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public updatestatus() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblEnterBookId = new JLabel("ENTER BOOK ID");
		lblEnterBookId.setBounds(29, 64, 93, 14);
		frame.getContentPane().add(lblEnterBookId);
		
		JLabel lblStatus = new JLabel("STATUS");
		lblStatus.setBounds(29, 103, 93, 14);
		frame.getContentPane().add(lblStatus);
		
		textField = new JTextField();
		textField.setBounds(123, 61, 168, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JRadioButton rdbtnAvailable = new JRadioButton("Available");
		rdbtnAvailable.setBounds(29, 124, 109, 23);
		frame.getContentPane().add(rdbtnAvailable);
		
		JRadioButton rdbtnNotAvailable = new JRadioButton("Not Available");
		rdbtnNotAvailable.setBounds(29, 157, 109, 23);
		frame.getContentPane().add(rdbtnNotAvailable);
		
		JLabel lblNoOfBook = new JLabel("No of book");
		lblNoOfBook.setBounds(29, 187, 93, 14);
		frame.getContentPane().add(lblNoOfBook);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(123, 184, 168, 20);
		frame.getContentPane().add(textField_1);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.setBounds(160, 215, 89, 23);
		frame.getContentPane().add(btnUpdate);
		
		JLabel lblUpdateStatus = new JLabel("UPDATE STATUS");
		lblUpdateStatus.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblUpdateStatus.setBounds(10, 11, 128, 14);
		frame.getContentPane().add(lblUpdateStatus);
	}
}
