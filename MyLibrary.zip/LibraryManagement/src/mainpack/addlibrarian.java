package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import com.toedter.calendar.JMonthChooser;
import java.awt.BorderLayout;
import com.toedter.calendar.JDayChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import javax.swing.JCheckBox;
import java.awt.Toolkit;

public class addlibrarian {
	String gender;
	private JFrame frmAddLibrarian;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addlibrarian window = new addlibrarian();
					window.frmAddLibrarian.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public addlibrarian() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frmAddLibrarian = new JFrame();
		frmAddLibrarian.setIconImage(Toolkit.getDefaultToolkit().getImage(addlibrarian.class.getResource("/lib/librnlogo.png")));
		frmAddLibrarian.getContentPane().setBackground(Color.PINK);
		frmAddLibrarian.setTitle("ADD LIBRARIAN");
		frmAddLibrarian.setBounds(100, 100, 600, 400);
		frmAddLibrarian.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAddLibrarian.getContentPane().setLayout(null);
		int x=1;
		JLabel lblName = new JLabel("NAME");
		lblName.setBounds(58, 119, 46, 14);
		frmAddLibrarian.getContentPane().add(lblName);
		
		JLabel lblDob = new JLabel("DOB\r\n");
		lblDob.setBounds(58, 144, 77, 14);
		frmAddLibrarian.getContentPane().add(lblDob);
		
		JLabel lblGender = new JLabel("GENDER");
		lblGender.setBounds(58, 174, 46, 14);
		frmAddLibrarian.getContentPane().add(lblGender);
		
		textField = new JTextField();
		textField.setBounds(156, 116, 187, 20);
		frmAddLibrarian.getContentPane().add(textField);
		textField.setColumns(10);
		
		
		
		JLabel lblPassword = new JLabel("PASSWORD");
		lblPassword.setBounds(58, 211, 77, 14);
		frmAddLibrarian.getContentPane().add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(156, 208, 150, 20);
		frmAddLibrarian.getContentPane().add(passwordField);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(155, 144, 188, 20);
		frmAddLibrarian.getContentPane().add(dateChooser);
		
		
		
		
		

		JCheckBox chckbxNewCheckBox = new JCheckBox("Male");
		chckbxNewCheckBox.setBounds(155, 170, 73, 23);
		
		
		JCheckBox JCheckBox = new JCheckBox("Male");
		frmAddLibrarian.getContentPane().add(chckbxNewCheckBox);
		JCheckBox.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				gender="M";
			}
		});


		
		
		
		
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("Female");
		chckbxNewCheckBox_1.setBounds(266, 170, 77, 23);
		JCheckBox JCheckBox1 = new JCheckBox("Male");
		frmAddLibrarian.getContentPane().add(chckbxNewCheckBox_1);
		chckbxNewCheckBox_1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				gender="F";
			}
		});

		
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String un,pw;
					double sal;
					String dt=null;
					un=textField.getText();
					pw=passwordField.getText();
					dt=dateChooser.getDateFormatString();
					gender=JCheckBox1.getText();
					
					
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
					dt=sdf.format(dateChooser.getDate()); 

					
					Class.forName("com.mysql.jdbc.Driver");
					   
					   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
					    String s="insert into librarian values(?,?,?,?)";
					    PreparedStatement ps=(PreparedStatement) con.prepareStatement(s);
					    ps.setString(1, un);
					    ps.setString(2, dt);
					    ps.setString(3, gender);
					    ps.setString(4, pw);
					   
					
					
					    int r=ps.executeUpdate();
					    if(r==1)
					    	JOptionPane.showMessageDialog(null, r+" Record Inserted");
					  
					}catch(Exception n) {
						JOptionPane.showMessageDialog(null, n);	
					}
				}
			});
			
	
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnAdd.setBackground(new Color(175, 238, 238));
		btnAdd.setBounds(139, 267, 89, 23);
		frmAddLibrarian.getContentPane().add(btnAdd);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
				passwordField.setText(null);
				dateChooser.setDate(null);
				JCheckBox.setText(null);
			}
			
		});
		btnReset.setBackground(new Color(175, 238, 238));
		btnReset.setBounds(254, 267, 89, 23);
		frmAddLibrarian.getContentPane().add(btnReset);
		
		JLabel lblAddLibrarian = new JLabel("ADD / UPDATE -LIBRARIAN");
		lblAddLibrarian.setFont(new Font("Microsoft Himalaya", Font.BOLD, 50));
		lblAddLibrarian.setBounds(10, 11, 564, 51);
		frmAddLibrarian.getContentPane().add(lblAddLibrarian);
		
		frmAddLibrarian.setVisible(true);
	
		
		
	
		
		
	}
}
