package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.border.SoftBevelBorder;

import com.mysql.jdbc.Connection;

import javax.swing.border.BevelBorder;
import java.awt.Toolkit;

public class homepage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					homepage window = new homepage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public homepage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(homepage.class.getResource("/lib/reading.png")));
		frame.setBounds(100, 100, 1024, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label_3 = new JLabel("");
		label_3.setBounds(57, 69, 46, 14);
		frame.getContentPane().add(label_3);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1009, 729);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNeedHelp = new JLabel("Need help ?");
		lblNeedHelp.setBounds(799, 414, 73, 14);
		panel.add(lblNeedHelp);
		lblNeedHelp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNeedHelp.setForeground(Color.BLUE);
				lblNeedHelp.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNeedHelp.setForeground(Color.black);
				lblNeedHelp.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null,"we are happy to help\n please visit- www.Library.com");
			}
		});
		lblNeedHelp.setFont(new Font("Tahoma", Font.ITALIC, 11));
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(713, 342, 214, 59);
		panel.add(label_2);
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label_2.setIcon(new ImageIcon(homepage.class.getResource("/lib/admin_B.png")));
				label_2.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				label_2.setIcon(new ImageIcon(homepage.class.getResource("/lib/admin_C.png")));
				label_2.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				new AdminLogin();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					//JOptionPane.showMessageDialog(null,"Driver Loaded");
					Connection con= 
							(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","root");
								    Statement st=con.createStatement();		
							st.executeUpdate("create database if not exists library");
							//JOptionPane.showMessageDialog(null,"Database Created");
							st.executeUpdate("use library");
											
					String s="create table if not exists admin(username varchar(10) primary key,password varchar(10))";
					st.executeUpdate(s);
				//	JOptionPane.showMessageDialog(null,"Admin Table Created");
					String add="insert into admin values('sameer','12345678')";
					st.executeUpdate(add);
					//JOptionPane.showMessageDialog(null,"Admin Added");
				}
				catch(Exception e1) { 
					JOptionPane.showMessageDialog(null, e1);
					
				}
			}
		});
		label_2.setIcon(new ImageIcon(homepage.class.getResource("/lib/admin_C.png")));
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(703, 275, 263, 59);
		panel.add(label_1);
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label_1.setIcon(new ImageIcon(homepage.class.getResource("/lib/librarian_B.png")));
				label_1.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				label_1.setIcon(new ImageIcon(homepage.class.getResource("/lib/librarian_C.png")));
				label_1.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				new LIBRARIANLOGIN();
			}
		});
		label_1.setIcon(new ImageIcon(homepage.class.getResource("/lib/librarian_C.png")));
		
		JLabel label = new JLabel("");
		label.setBounds(718, 210, 204, 59);
		panel.add(label);
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label.setIcon(new ImageIcon(homepage.class.getResource("/lib/user_B.png")));
				label.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				label.setIcon(new ImageIcon(homepage.class.getResource("/lib/user_C.png")));
				label.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				new userlogin();
			}
		});
		label.setIcon(new ImageIcon(homepage.class.getResource("/lib/user_C.png")));
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(945, 0, 64, 66);
		panel.add(label_4);
		label_4.setIcon(new ImageIcon(homepage.class.getResource("/lib/icons8-book-shelf-64.png")));
		
		JButton btnNewButton = new JButton(" Exit ");
		btnNewButton.setBounds(909, 693, 90, 25);
		panel.add(btnNewButton);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		});
		ActionListener al = new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        System.exit(0);
		    }
		};

		btnNewButton.addActionListener(al);
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 20));
		btnNewButton.setBackground(new Color(255, 99, 71));
		
		JLabel lblWelcomeToLibrark = new JLabel("WELCOME TO LIBRARY");
		lblWelcomeToLibrark.setFont(new Font("Arial", Font.BOLD, 30));
		lblWelcomeToLibrark.setBounds(321, 0, 471, 60);
		panel.add(lblWelcomeToLibrark);
		
		JLabel label_5 = new JLabel("");
		label_5.setIcon(new ImageIcon(homepage.class.getResource("/lib/mainpage.png")));
		label_5.setBounds(0, 0, 1009, 729);
		panel.add(label_5);
	}
}
