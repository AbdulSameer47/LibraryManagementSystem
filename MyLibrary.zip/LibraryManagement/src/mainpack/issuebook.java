package mainpack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

public class issuebook {

	private JFrame frmIssueBook;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					issuebook window = new issuebook();
					window.frmIssueBook.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public issuebook() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmIssueBook = new JFrame();
		frmIssueBook.setTitle("ISSUE BOOK");
		frmIssueBook.setBounds(100, 100, 450, 300);
		frmIssueBook.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmIssueBook.getContentPane().setLayout(null);
		
		JLabel lblStudentId = new JLabel("STUDENT ID");
		lblStudentId.setBounds(124, 53, 80, 14);
		frmIssueBook.getContentPane().add(lblStudentId);
		
		JLabel lblBookId = new JLabel("BOOK ID\r\n");
		lblBookId.setBounds(124, 91, 80, 14);
		frmIssueBook.getContentPane().add(lblBookId);
		
		JLabel lblIssueDate = new JLabel("ISSUE DATE");
		lblIssueDate.setBounds(124, 135, 80, 14);
		frmIssueBook.getContentPane().add(lblIssueDate);
		
		textField = new JTextField();
		textField.setBounds(233, 50, 86, 20);
		frmIssueBook.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(233, 88, 86, 20);
		frmIssueBook.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(233, 132, 86, 20);
		frmIssueBook.getContentPane().add(textField_2);
		
		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setBounds(82, 195, 89, 23);
		frmIssueBook.getContentPane().add(btnSubmit);
		
		JButton btnReset = new JButton("RESET");
		btnReset.setBounds(263, 195, 89, 23);
		frmIssueBook.getContentPane().add(btnReset);
		
		JLabel lblIssueBook = new JLabel("ISSUE BOOK");
		lblIssueBook.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblIssueBook.setBounds(23, 11, 80, 14);
		frmIssueBook.getContentPane().add(lblIssueBook);
	}
}
